<?php
if (!defined('APP_BOOTSTRAPPED')) { http_response_code(403); exit; }

require_once __DIR__ . '/../libs/PHPMailer/Exception.php';
require_once __DIR__ . '/../libs/PHPMailer/PHPMailer.php';
require_once __DIR__ . '/../libs/PHPMailer/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception as PHPMailerException;

/**
 * Wysyla maila do listy adresow. Jesli SMTP nie jest skonfigurowany w config.php,
 * tresc jest tylko dopisywana do logs/mail.log (przydatne do testow lokalnych).
 */
function send_mail_to(array $recipients, string $subject, string $text) {
    $recipients = array_values(array_filter($recipients));
    if (empty($recipients)) return;

    if (SMTP_HOST === '') {
        $line = "--- [" . date('Y-m-d H:i:s') . "] ---\n";
        $line .= "Do: " . implode(', ', $recipients) . "\n";
        $line .= "Temat: $subject\n\n$text\n";
        $line .= "--------------------------------------\n\n";
        $logDir = __DIR__ . '/../logs';
        if (!is_dir($logDir)) mkdir($logDir, 0777, true);
        file_put_contents($logDir . '/mail.log', $line, FILE_APPEND);
        return;
    }

    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = SMTP_HOST;
        $mail->Port = SMTP_PORT;
        if (SMTP_SECURE !== '') $mail->SMTPSecure = SMTP_SECURE;
        if (SMTP_USER !== '') {
            $mail->SMTPAuth = true;
            $mail->Username = SMTP_USER;
            $mail->Password = SMTP_PASS;
        }
        $mail->CharSet = 'UTF-8';
        $mail->setFrom(MAIL_FROM_EMAIL, MAIL_FROM_NAME);
        foreach ($recipients as $r) $mail->addAddress($r);
        $mail->Subject = $subject;
        $mail->Body = $text;
        $mail->send();
    } catch (PHPMailerException $e) {
        error_log('Blad wysylki maila: ' . $mail->ErrorInfo);
    }
}

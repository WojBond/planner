<?php if (!defined('APP_BOOTSTRAPPED')) { http_response_code(403); exit; } ?>
</div>
</body>
</html>

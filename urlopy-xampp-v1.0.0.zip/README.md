# Planer urlopow (wersja pod XAMPP: PHP + MySQL)

**Wersja: 1.0.0** (numer wersji trzymany w `config.php` jako `APP_VERSION`,
widoczny tez w interfejsie obok nazwy aplikacji).

To jest wersja aplikacji "Planer urlopow" przystosowana do uruchomienia na
serwerze Apache z PHP i MySQL, tak jak dostarcza je XAMPP. Funkcje sa
identyczne jak w wersji Node.js:

1. Admin tworzy uzytkownikow i grupy uzytkownikow (dzialy).
2. Logowanie z rolami: **user** widzi swoje zdarzenia i zdarzenia swojego
   dzialu, **admin** widzi wszystkie zdarzenia.
3. Kazdy uzytkownik wybiera wlasny kolor paska w kalendarzu.
4. Po dodaniu zdarzenia system wysyla e-mail do wszystkich osob w danym dziale.

## Instalacja (krok po kroku)

1. Zainstaluj [XAMPP](https://www.apachefriends.org/) (Apache + MySQL + PHP,
   wersja PHP 8.x).
2. Uruchom **Apache** i **MySQL** w panelu XAMPP Control Panel.
3. Skopiuj caly folder `urlopy-xampp` do katalogu `htdocs` XAMPP, np.:
   - Windows: `C:\xampp\htdocs\urlopy\`
   - (czyli zawartosc tego folderu, nie sam folder `urlopy-xampp` w srodku
     kolejnego podfolderu — pliki `index.php`, `login.php` itd. maja lezec
     bezposrednio w `C:\xampp\htdocs\urlopy\`)
4. Otworz w przegladarce: `http://localhost/urlopy/`
5. Baza danych `urlopy` oraz wszystkie tabele **tworza sie automatycznie**
   przy pierwszym wejsciu na strone (polaczenie do MySQL jako `root` bez
   hasla — domyslne ustawienia XAMPP). Tworzy sie tez domyslne konto
   administratora.

Domyslne konto administratora:

- e-mail: `admin@firma.local`
- haslo: `admin123`

**Zmien to haslo od razu po pierwszym zalogowaniu** (Moj profil -> Zmiana hasla).

### Jesli Twoj MySQL ma inne dane logowania

Jesli zmieniles haslo do `root` w MySQL (albo uzywasz innego uzytkownika),
zmien dane w pliku [`config.php`](config.php):

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'urlopy');
define('DB_USER', 'root');
define('DB_PASS', '');
```

Plik [`schema.sql`](schema.sql) jest dolaczony wylacznie jako dokumentacja
struktury bazy / do recznego importu przez phpMyAdmin — nie jest wymagany,
bo aplikacja tworzy tabele sama.

## Konfiguracja wysylki e-mail

Bez konfiguracji SMTP aplikacja dziala normalnie, ale tresc maili jest
zapisywana do pliku `logs/mail.log` zamiast byc faktycznie wyslana
(przydatne do testow).

Aby wysylac prawdziwe maile, uzupelnij w `config.php`:

```php
define('SMTP_HOST', 'smtp.twojafirma.pl');
define('SMTP_PORT', 587);
define('SMTP_SECURE', 'tls'); // albo 'ssl'
define('SMTP_USER', 'twoj_login_smtp');
define('SMTP_PASS', 'twoje_haslo_smtp');
define('MAIL_FROM_EMAIL', 'urlopy@twojafirma.pl');
define('MAIL_FROM_NAME', 'Planer urlopow');
```

Wysylka realizowana jest przez dolaczona biblioteke PHPMailer
(`libs/PHPMailer/`), bez potrzeby instalowania Composera.

## Typy zdarzen

Urlop wypoczynkowy, Urlop na zadanie, Urlop z nadgodzin, Wizyta lekarska, Inne.

## Struktura projektu

```
urlopy-xampp/
  config.php          - konfiguracja bazy danych i SMTP
  schema.sql           - opcjonalny, reczny import struktury bazy
  bootstrap.php         - wspolny start kazdej strony (sesja, polaczenia)
  index.php, login.php, logout.php
  calendar.php          - widok kalendarza (FullCalendar)
  api_events.php        - zwraca zdarzenia jako JSON (filtrowane wg roli)
  events_create.php, events_delete.php
  profile.php, profile_color.php, profile_password.php
  admin_users.php, admin_groups.php
  includes/             - polaczenie z baza, autoryzacja, layout
  libs/PHPMailer/        - biblioteka do wysylki e-mail (SMTP)
  assets/                - CSS i biblioteka kalendarza (FullCalendar)
  logs/mail.log          - log wyslanych/probowanych maili
```

## Uwagi bezpieczenstwa

- Hasla sa haszowane (`password_hash`/`password_verify`), nigdy nie sa
  przechowywane w postaci czystego tekstu.
- Sesja logowania oparta na natywnych sesjach PHP.
- Katalog `logs/` powinien byc niedostepny publicznie w srodowisku
  produkcyjnym (w tej wersji deweloperskiej pod XAMPP nie ma to znaczenia).
- Przed wystawieniem aplikacji poza siec lokalna: ustaw haslo do MySQL
  (nie zostawiaj `root` bez hasla), rozwaz HTTPS oraz wylacz wyswietlanie
  bledow PHP na produkcji (`display_errors = Off` w `php.ini`).

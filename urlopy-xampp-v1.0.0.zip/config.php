<?php
// Konfiguracja aplikacji "Planer urlopow" pod XAMPP.
// Domyslne wartosci pasuja do domyslnej instalacji XAMPP (MySQL: root bez hasla).

define('APP_VERSION', '1.0.0');
define('APP_CHANGELOG', [
    '1.0.0' => [
        'date' => '2026-09-29',
        'changes' => [
            'Pierwsza wersja: logowanie i role (user/admin), tworzenie uzytkownikow i dzialow,',
            'wybor koloru paska, powiadomienia e-mail o nowych zdarzeniach dla dzialu.',
        ],
    ],
]);

define('DB_HOST', 'localhost');
define('DB_NAME', 'urlopy');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// Konfiguracja SMTP do wysylki prawdziwych maili.
// Jesli SMTP_HOST jest puste, tresc maili jest tylko zapisywana w logs/mail.log
// (przydatne do testow bez konfigurowania serwera pocztowego).
define('SMTP_HOST', '');
define('SMTP_PORT', 587);
define('SMTP_SECURE', 'tls'); // 'tls', 'ssl' albo ''
define('SMTP_USER', '');
define('SMTP_PASS', '');
define('MAIL_FROM_EMAIL', 'urlopy@firma.local');
define('MAIL_FROM_NAME', 'Planer urlopow');

define('SESSION_NAME', 'urlopy_session');

// Domyslne haslo konta admina tworzonego przy pierwszym uruchomieniu.
define('DEFAULT_ADMIN_EMAIL', 'admin@firma.local');
define('DEFAULT_ADMIN_PASSWORD', 'admin123');

<?php
if (!defined('APP_BOOTSTRAPPED')) { http_response_code(403); exit; }

require_once __DIR__ . '/db.php';

function start_app_session() {
    if (session_status() === PHP_SESSION_NONE) {
        session_name(SESSION_NAME);
        session_start();
    }
}

function current_user() {
    start_app_session();
    if (empty($_SESSION['user_id'])) return null;
    static $cached = null;
    if ($cached !== null) return $cached;
    $pdo = get_pdo();
    $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ?');
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    $cached = $user ?: null;
    return $cached;
}

function require_auth() {
    $user = current_user();
    if (!$user) {
        $next = $_SERVER['REQUEST_URI'] ?? '';
        $loginUrl = 'login.php';
        if ($next !== '' && strpos($next, 'login.php') === false) {
            $loginUrl .= '?next=' . urlencode($next);
        }
        header('Location: ' . $loginUrl);
        exit;
    }
    return $user;
}

/** Bezpieczny cel przekierowania po zalogowaniu - tylko wzgledna sciezka we wlasnej aplikacji. */
function safe_next_url($raw) {
    $raw = trim((string) $raw);
    if ($raw === '') return 'calendar.php';
    if (strpos($raw, '://') !== false) return 'calendar.php';
    if (substr($raw, 0, 2) === '//') return 'calendar.php';
    return $raw;
}

function require_admin() {
    $user = require_auth();
    if ($user['role'] !== 'admin') {
        http_response_code(403);
        render_error('Brak uprawnien administratora.');
        exit;
    }
    return $user;
}

function render_error($message) {
    $currentUser = current_user();
    include __DIR__ . '/../error.php';
}

function e($str) {
    return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8');
}
